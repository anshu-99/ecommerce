<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,inital-scale=1.0">
	<title> All Products- YourStore </title>
	<link rel="stylesheet" type="text/css" href="ecom.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lobster&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

		<div class="container">
		<div class="navbar">
		<div class="logo">
			<a href="index.php"><img src="img/log.png" width="125px"></a>
		</div>
		<nav>
			<ul id="Menuitems">
				<li><a href="index.php"> HOME </a></li>
				<li><a href="product.php"> PRODUCTS </a></li>
				<li><a href="about.php"> ABOUT </a></li>
				<li><a href="conn.php"> CONTACT </a></li>
				<?php
	        if (isset($_SESSION['email'])) {
	          echo "<li><a href='profile.php'> PROFILE </a></li>";
	        }
	        else {
	          echo "<li><a href='account.php'> ACCOUNT </a></li>";
	        }
	      ?>

			</ul>
		</nav>
		<a href="cart.php"><img src="img/cart.png" width="30px" height="30px"></a>
		<img src="img/menu.png" class="menu-icon" onclick="menutoggle()">
		</div>
  </div>
  <div class="small-container">
    <div class="row row-2">
      <h2>All Products</h2>
      <select>
        <option>Deafault Shorting</option>
        <option>Short by Price</option>
        <option>Short by popularity</option>
        <option>Short by rating</option>
        <option>Short by sale</option>
      </select>

    </div>
<div class="row">
  		<div class="col-4">
  			<a href="product details.php"><img src="img/product-1.jpg"></a>
  			<h4>Red Printed T-shirt</h4>
  			<div class="rating">
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star-o"></i>


  			</div>
  			<p>$50.00</p>
  		</div>
  		<div class="col-4">
  			<img src="img/product-2.jpg">
  			<h4>Sports shoes by HRX</h4>
  			<div class="rating">
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star-half-o"></i>


  			</div>
  			<p>$60.00</p>
  		</div>
  		<div class="col-4">
  			<img src="img/product-3.jpg">
  			<h4>Sports Jogger</h4>
  			<div class="rating">
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star-half-o"></i>


  			</div>
  			<p>$40.00</p>
  		</div>
  		<div class="col-4">
  			<img src="img/product-4.jpg">
  			<h4>Blue T-shirt</h4>
  			<div class="rating">
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>
  				 <i class="fa fa-star" ></i>


  			</div>
  			<p>$50.00</p>
  		</div>
      <div class="row">
    <div class="col-4">
        <img src="img/product-5.jpg">
        <h4>Casual shoes</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-o"></i>


        </div>
        <p>$75.00</p>
      </div>

          <div class="col-4">
        <img src="img/product-6.jpg">
        <h4>Black active T-shirt by PUMA</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$80.00</p>
      </div>
      <div class="col-4">
        <img src="img/product-7.jpg">
        <h4>Socks by HRX</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$70.00</p>
      </div>
      <div class="col-4">
        <img src="img/product-8.jpg">
        <h4>Watch by FOSSIL</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>


        </div>
        <p>$80.00</p>
      </div>

    </div>
    <div class="row">
    <div class="col-4">
        <img src="img/product-9.jpg">
        <h4>Leather strap watch by Rodster</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-o"></i>


        </div>
        <p>$75.00</p>
      </div>
      <div class="col-4">
        <img src="img/product-10.jpg">
        <h4>Sports Shoes by HRX</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$70.00</p>
      </div>
      <div class="col-4">
        <img src="img/product-11.jpg">
        <h4>Running Shoes by Roadster</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$55.00</p>
      </div>
      <div class="col-4">
        <img src="img/product-12.jpg">
        <h4>Sports jogger by NIKE</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>


        </div>
        <p>$65.00</p>
      </div>

    </div>
    <div class="page-btn">
      <span>1</span>
     <a href="pro.php"><span>2</span></a>

    </div>

  	</div>
    <!-------------Footer---------->
  <div class="footer">
    <div class="container">
      <div class="row">
        <div class="footer-col-1">
          <h3>Download our app</h3>
          <p> Download our app for Android and ios phones.</p>
          <div class="app-logo">
            <img src="img/play-store.png">
            <img src="img/app-store.png">

          </div>
            </div>
            <div class="footer-col-2">
          <img src="img/log.png">
          <p> Our purpose is to sustainably make the pleasure and
          benifits of sports accessible to the many. </p>
            </div>
            <div class="footer-col-3">
          <h3>Useful links</h3>
          <ul>
            <li> Coupons </li>
            <li> Blog Post </li>
            <li> Return Policy </li>
            <li> Join Affiliate </li>
                </ul>
            </div>
            <div class="footer-col-4">
          <h3> Follow us </h3>
          <ul>
            <li> Facebook </li>
            <li> Twitter </li>
            <li> Instagram </li>
            <li> Youtube </li>
                </ul>
            </div>

      </div>
      <hr>
      <p class="Copyright"> Copyright-2021 (YourStore)</p>

    </div>

  </div>


  <!----------js for toggle menu------------->
  <script>
  	var Menuitems = document.getElementById("Menuitems");

  	Menuitems.style.maxHeight = "0px";

  	function menutoggle(){
  	   if (Menuitems.style.maxHeight == "0px")
  		 {
  			Menuitems.style.maxHeight = "200px";
  		 }
  	   else
  	    {
  	   	Menuitems.style.maxHeight = "0px";
        }

  	}
  </script>


</body>
</html>
