<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,inital-scale=1.0">
	<title> About </title>
	<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="ecom.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lobster&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="header">
		<div class="container">
            <div class="navbar">
                <div class="logo">
                    <a href="index.php"><img src="img/log.png" width="125px"></a>
                </div>
                <nav>
                    <ul id="Menuitems">
                        <li><a href="index.php"> HOME </a></li>
                        <li><a href="product.php"> PRODUCTS </a></li>
                        <li><a href="about.php"> ABOUT </a></li>
                        <li><a href="conn.php"> CONTACT </a></li>
                        <?php
                    if (isset($_SESSION['email'])) {
                      echo "<li><a href='profile.php'> PROFILE </a></li>";
                    }
                    else {
                      echo "<li><a href='account.php'> ACCOUNT </a></li>";
                    }
                  ?>

                    </ul>
                </nav>
                <a href="cart.php"><img src="img/cart.png" width="30px" height="30px"></a>
                <img src="img/menu.png" class="menu-icon" onclick="menutoggle()">
            </div>

            <div class="about-section">
                <div class="inner-container">
                    <h1>About Us</h1>
                    <p class="text">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus velit ducimus, enim inventore earum, eligendi nostrum pariatur necessitatibus eius dicta a voluptates sit deleniti autem error eos totam nisi neque voluptates sit deleniti autem error eos totam nisi neque.
                    </p>
                    <div class="skills">
                        <span>Web Design</span>
                        <span>Photoshop & Illustrator</span>
                        <span>Coding</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>