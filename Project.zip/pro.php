<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,inital-scale=1.0">
  <title> All Products- YourStore </title>
  <link rel="stylesheet" type="text/css" href="ecom.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lobster&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

    <div class="container">
    <div class="navbar">
    <div class="logo">
      <a href="index.php"><img src="img/log.png" width="125px"></a>
    </div>
    <nav>
      <ul id="Menuitems">
        <li><a href="index.php"> HOME </a></li>
        <li><a href="product.php"> PRODUCTS </a></li>
        <li><a href="about.php"> ABOUT </a></li>
        <li><a href="conn.php"> CONTACT </a></li>
        <?php
          if (isset($_SESSION['email'])) {
            echo "<li><a href='profile.php'> PROFILE </a></li>";
          }
          else {
            echo "<li><a href='account.php'> ACCOUNT </a></li>";
          }
        ?>

      </ul>
    </nav>
    <a href="cart.php"><img src="img/cart.png" width="30px" height="30px"></a>
    <img src="img/menu.png" class="menu-icon" onclick="menutoggle()">
    </div>
  </div>
  <div class="small-container">
    <div class="row row-2">
      <h2>All Products</h2>
      <select>
        <option>Deafault Shorting</option>
        <option>Short by Price</option>
        <option>Short by popularity</option>
        <option>Short by rating</option>
        <option>Short by sale</option>
      </select>

    </div>
<div class="row">
      <div class="col-4">
      <a href="pro1.php"><img src="img/bo1.jpg"></a>
        <h4>boAT storm smartwatch</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-o"></i>


        </div>
        <p>$50.00</p>
      </div>
      <div class="col-4">
       <a href="pro2.php"><img src="img/p1.jpg"></a>
        <h4>sports bra for women</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$60.00</p>
      </div>
      <div class="col-4">
        <a href="pro3.php"><img src="img/r1.jpg"></a>
        <h4>black running shoes</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$40.00</p>
      </div>
      <div class="col-4">
        <a href="pro4.php"><img src="img/s1.jpg"></a>
        <h4>comfy white sneakers by adidas</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>


        </div>
        <p>$50.00</p>
      </div>
      <div class="row">
    <div class="col-4">
        <img src="img/tt1.jpg">
        <h4>cool black t-shirt</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-o"></i>


        </div>
        <p>$75.00</p>
      </div>

          <div class="col-4">
        <img src="img/w1.jpg">
        <h4>Black active women jogger by PUMA</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$80.00</p>
      </div>
      <div class="col-4">
        <img src="img/ww1.jpg">
        <h4>casual watch for women</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$70.00</p>
      </div>
      <div class="col-4">
        <img src="img/ts1.jpg">
        <h4>marroon funky t-shirt </h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>


        </div>
        <p>$80.00</p>
      </div>

    </div>
    <div class="row">
    <div class="col-4">
        <img src="img/rn1.jpg">
        <h4>sneaker </h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-o"></i>


        </div>
        <p>$75.00</p>
      </div>
      <div class="col-4">
        <img src="img/ty1.jpg">
        <h4>comfy sports wear</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$70.00</p>
      </div>
      <div class="col-4">
        <img src="img/ek1.jpg">
        <h4>nike t-shirt</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star-half-o"></i>


        </div>
        <p>$55.00</p>
      </div>
      <div class="col-4">
        <img src="img/jo1.jpg">
        <h4>jogger pant for women</h4>
        <div class="rating">
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>
           <i class="fa fa-star" ></i>


        </div>
        <p>$65.00</p>
      </div>

    </div>
    <div class="page-btn">
     <a href="product.php"><span>1</span></a>
      <span>2</span>

    </div>

    </div>
    <!-------------Footer---------->
  <div class="footer">
    <div class="container">
      <div class="row">
        <div class="footer-col-1">
          <h3>Download our app</h3>
          <p> Download our app for Android and ios phones.</p>
          <div class="app-logo">
            <img src="img/play-store.png">
            <img src="img/app-store.png">

          </div>
            </div>
            <div class="footer-col-2">
          <img src="img/log.png">
          <p> Our purpose is to sustainably make the pleasure and
          benifits of sports accessible to the many. </p>
            </div>
            <div class="footer-col-3">
          <h3>Useful links</h3>
          <ul>
            <li> Coupons </li>
            <li> Blog Post </li>
            <li> Return Policy </li>
            <li> Join Affiliate </li>
                </ul>
            </div>
            <div class="footer-col-4">
          <h3> Follow us </h3>
          <ul>
            <li> Facebook </li>
            <li> Twitter </li>
            <li> Instagram </li>
            <li> Youtube </li>
                </ul>
            </div>

      </div>
      <hr>
      <p class="Copyright"> Copyright-2021 (YourStore)</p>

    </div>

  </div>


  <!----------js for toggle menu------------->
  <script>
    var Menuitems = document.getElementById("Menuitems");

    Menuitems.style.maxHeight = "0px";

    function menutoggle(){
       if (Menuitems.style.maxHeight == "0px")
       {
        Menuitems.style.maxHeight = "200px";
       }
       else
        {
        Menuitems.style.maxHeight = "0px";
        }

    }
  </script>


</body>
</html>
