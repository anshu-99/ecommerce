<?php
session_start();

$con = mysql_connect('localhost','root', '');

mysqli_select_db($con,'registration_login');

$name = $_POST['Username'];
$pass = $_POST['password'];
$s ="select * from login where name='$name' && password= '$pass' ";
$result= mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if ($num==1){
	header('location:home.php');
	# code...
}
else{
	header('location:login.php');
	

}
?>