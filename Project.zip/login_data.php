<?php
$con = mysqli_connect('localhost', 'root', '');
mysqli_select_db($con, 'project');

if(isset($_POST['login'])) {
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $s = "select * from register where email = '$email' && password = '$pass'";
    $result = mysqli_query($con, $s);
    $num = mysqli_num_rows($result);
    echo $num;
    if ($num == 1){
        $_SESSION["email"] = $email;
        echo $_SESSION['email'];
        header('location:index.php');
    }
    else{
        header('location:account.php');
        echo "<script>alert('oops! Email or Password is wrong!')</script>";
    }
}
?>
