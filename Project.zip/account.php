<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,inital-scale=1.0">
	<title> All Products- YourStore </title>
	<link rel="stylesheet" type="text/css" href="ecom.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lobster&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<!--------account-page------>
<div class="account-page">
  <div class="container">
    <div class="navbar">
		<div class="logo">
            <a href="index.php"><img src="img/log.png" width="125px"></a>
        </div>
		<nav>
			<ul id="Menuitems">
				<li><a href="index.php"> HOME </a></li>
				<li><a href="product.php"> PRODUCTS </a></li>
				<li><a href="about.php"> ABOUT </a></li>
				<li><a href="conn.php"> CONTACT </a></li>
				<?php
	        if (isset($_SESSION['email'])) {
	          echo "<li><a href='profile.php'> PROFILE </a></li>";
	        }
	        else {
	          echo "<li><a href='account.php'> ACCOUNT </a></li>";
	        }
	      ?>

			</ul>
		</nav>
		<a href="cart.php"><img src="img/cart.png" width="30px" height="30px"></a>
		<img src="img/menu.png" class="menu-icon" onclick="menutoggle()">
	</div>
    <div class="row">
      <div class="col-2">
        <img src="img/image1.png" width="100%">
      </div>
      <div class="col-2">
        <div class="form-container">
          <div class="form-btn">
            <span onclick="login()">Login</span>
            <span onclick="reg()">Register</span>
            <hr id="indicator">

          </div>
          <form id="Loginform" action="login_data.php" method="post">
            <input type="text" name="email" placeholder="Username">
            <input type="password" name="pass" placeholder="password">
            <button type="Submit" name="login" class="btn">Login</button>
            <a href="">Forgot Password</a>
          </form>

          <form id="Regform" action="register_data.php" method="post">
            <input type="text" name="user" placeholder="Username">
            <input type="text" name="email" placeholder="E-mail">
            <input type="password" name="pass" placeholder="password">
            <button type="Submit" name="register" class="btn">Register</button>
          </form>

        </div>
      </div>
    </div>

  </div>

</div>
<!-------------Footer---------->
  <div class="footer">
    <div class="container">
      <div class="row">
        <div class="footer-col-1">
          <h3>Download our app</h3>
          <p> Download our app for Android and ios phones.</p>
          <div class="app-logo">
            <img src="img/play-store.png">
            <img src="img/app-store.png">

          </div>
            </div>
            <div class="footer-col-2">
          <img src="img/log.png">
          <p> Our purpose is to sustainably make the pleasure and
          benifits of sports accessible to the many. </p>
            </div>
            <div class="footer-col-3">
          <h3>Useful links</h3>
          <ul>
            <li> Coupons </li>
            <li> Blog Post </li>
            <li> Return Policy </li>
            <li> Join Affiliate </li>
                </ul>
            </div>
            <div class="footer-col-4">
          <h3> Follow us </h3>
          <ul>
            <li> Facebook </li>
            <li> Twitter </li>
            <li> Instagram </li>
            <li> Youtube </li>
                </ul>
            </div>

      </div>
      <hr>
      <p class="Copyright"> Copyright-2021 (YourStore)</p>

    </div>

  </div>


  <!----------js for toggle menu------------->
  <script>
  	var Menuitems = document.getElementById("Menuitems");

  	Menuitems.style.maxHeight = "0px";

  	function menutoggle()
    {
  	   if (Menuitems.style.maxHeight == "0px")
  		 {
  			Menuitems.style.maxHeight = "200px";
  		 }
  	   else
  	    {
  	   	Menuitems.style.maxHeight = "0px";
        }

  	}
  </script>
  <!-------js for login----->
  <script>
    var Loginform= document.getElementById("Loginform")
    var RegForm= document.getElementById("Regform")
    var Indicator= document.getElementById("indicator")

      function reg(){
        Regform.style.transform="translatex(0px)";
        Loginform.style.transform="translatex(0px)";
        Indicator.style.transform="translatex(100px)";

      }
       function login(){
        Regform.style.transform="translatex(300px)";
        Loginform.style.transform="translatex(300px)";
         Indicator.style.transform="translatex(0px)";
      }

  </script>

</body>
</html>
