<?php

$con = mysqli_connect("localhost", "root", "");
mysqli_select_db($con, 'project');

if (isset($_POST['register'])) {
    $name = $_POST['user'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $s = "select * from register where email='$email'";
    $result = mysqli_query($con, $s);
    $num = mysqli_num_rows($result);

    if ($num == 1) {
        echo "<script>alert('Email is already registered')</script>";
    }
    else{
        $_SESSION["email"]= $email;
        $reg = "insert into register (userid, email, password) value ('$name', '$email', '$pass')";
        mysqli_query($con, $reg);
        echo "<script>alert('Registration successful')</script>";
        header('location:account.php');
    }
}
?>
