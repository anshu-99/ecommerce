<?php
session_start();

$con = mysqli_connect("localhost", "root", "");
mysqli_select_db($con, 'comment');

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $sub = $_POST['subject'];
    $massage = $_POST['massage'];
    $s = "insert into register (id, name, phone, email, subject, massage) value('', '$name', '$phone', '$email', '$sub', '$massage')";
    $result = mysqli_query($con, $s);
    $num = mysqli_num_rows($result);

    if ($num == 1) {
        echo "<script>alert('your comment is successfully registered')</script>";
        echo mysqli_error();
        header('location:index.php');
    }
    else{
        echo "<script>alert('Ooops! something wrong.....')</script>";
        echo mysqli_error();
        header('location:conn.php');
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,inital-scale=1.0">
	<title> Your Store </title>
	<link rel="stylesheet" type="text/css" href="ecom.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lobster&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="header">
		<div class="container">
		<div class="navbar">
		<div class="logo">
			<a href="index.php"><img src="img/log.png" width="125px"></a>
		</div>
		<nav>
			<ul id="Menuitems">
				<li><a href="index.php"> HOME </a></li>
				<li><a href="product.php"> PRODUCTS </a></li>
				<li><a href="about.php"> ABOUT </a></li>
				<li><a href="conn.php"> CONTACT </a></li>
				<?php
	        if (isset($_SESSION['email'])) {
	          echo "<li><a href='profile.php'> PROFILE </a></li>";
	        }
	        else {
	          echo "<li><a href='account.php'> ACCOUNT </a></li>";
	        }
	      ?>

			</ul>
		</nav>
		<a href="cart.html"><img src="img/cart.png" width="30px" height="30px"></a>
		<img src="img/menu.png" class="menu-icon" onclick="menutoggle()">


	</div>

  <div class="container">

  <h1> Connect with us </h1>
    <p> We would love to respond your queries and solve your problem<br> feel free to get in touch with us. </p>
    <div class="contact-box">
      <div class="contact-left">
        <h3>Sent your request</h3>
        <form action="conn.php" method="post">
          <div class="input-row">
            <div class="input-group">
              <label> Name </label>
              <input type="text" name="name" placeholder="Udbhav Ojha">

            </div>
            <div class="input-group">
              <label> Phone </label>
              <input type="text" name="phone" placeholder="+91 1234567890">
              </div>

          </div>
          <div class="input-row">
            <div class="input-group">
              <label> e-mail </label>
              <input type="email" name="email" placeholder="udb@gmail.com">

            </div>
            <div class="input-group">
              <label> Subject </label>
              <input type="text" name="subject" placeholder="type your query">
              </div>

          </div>
          <label> Message </label>
          <textarea name="massage" rows="5" placeholder="Your Message"></textarea>
          <button type="submit" name="submit"> Send </button>
        </form>
      </div>
      <div class="contact-right">
        <h3>Reach us</h3>
        <table>

          <tr>

            <td>Email</td>
            <td>contactus@example.com</td>
          </tr>
          <tr>

            <td>Phone</td>
            <td>+91 657 893 4560</td>
          </tr>
          <tr>

            <td> Adress </td>
            <td> #212, ground floor,7th cross<br>
              some layout,some road,Koromangla<br>
              Bengaluru,5600001

          </td>
          </tr>
        </table>
      </div>

    </div>
    </div>
  <!-------------Footer---------->
  <div class="footer">
  	<div class="container">
  		<div class="row">
  			<div class="footer-col-1">
  				<h3>Download our app</h3>
  				<p> Download our app for Android and ios phones.</p>
  				<div class="app-logo">
  					<img src="img/play-store.png">
  					<img src="img/app-store.png">

  				</div>
            </div>
            <div class="footer-col-2">
  				<img src="img/log.png">
  				<p> Our purpose is to sustainably make the pleasure and
  				benifits of sports accessible to the many. </p>
            </div>
            <div class="footer-col-3">
  				<h3>Useful links</h3>
  				<ul>
  					<li> Coupons </li>
  					<li> Blog Post </li>
  					<li> Return Policy </li>
  					<li> Join Affiliate </li>
                </ul>
            </div>
            <div class="footer-col-4">
  				<h3> Follow us </h3>
  				<ul>
  					<li> Facebook </li>
  					<li> Twitter </li>
  					<li> Instagram </li>
  					<li> Youtube </li>
                </ul>
            </div>

  		</div>
  		<hr>
  		<p class="Copyright"> Copyright-2021 (YourStore)</p>

  	</div>

  </div>
  <!----------js for toggle menu------------->
  <script>
  	var Menuitems = document.getElementById("Menuitems");

  	Menuitems.style.maxHeight = "0px";

  	function menutoggle(){
  	   if (Menuitems.style.maxHeight == "0px")
  		 {
  			Menuitems.style.maxHeight = "200px";
  		 }
  	   else
  	    {
  	   	Menuitems.style.maxHeight = "0px";
        }

  	}
  </script>


</body>
</html>
