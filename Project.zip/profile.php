<?php

session_start();

?>
<html lang="en">

<head>
    <title>Profile</title>
    <meta charset="utf-8">
  	<meta name="viewport" content="width=device-width,inital-scale=1.0">
  	<link rel="stylesheet" type="text/css" href="ecom.css">
  	<link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
  <div class="container">
  <div class="navbar">
  <div class="logo">
    <a href="index.php"><img src="img/log.png" width="125px"></a>

  </div>
  <nav>
    <ul id="Menuitems">
      <li><a href="index.php"> HOME </a></li>
      <li><a href="product.php"> PRODUCTS </a></li>
      <li><a href="about.php"> ABOUT </a></li>
      <li><a href="conn.php"> CONTACT </a></li>
      <?php
        if (isset($_SESSION["email"])) {
          echo "<li><a href='profile.php'> PROFILE </a></li>";
        }
        else {
          echo "<li><a href='account.php'> ACCOUNT </a></li>";
        }
      ?>
      </ul>
    </nav>
    <a href="cart.php"><img src="img/cart.png" width="30px" height="30px"></a>
		<img src="img/menu.png" class="menu-icon" onclick="menutoggle()">
		</div>
  </div>
</div>
<div class="account-page">
    <?php echo "<h1>Welcome " . $_SESSION["email"] . "</h1>"; ?>
    <h2><a href = "logout.php">Log Out</a></h2>
</div>
</body>

</html>
